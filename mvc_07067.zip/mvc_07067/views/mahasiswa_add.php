<form method="POST" action="index.php?page=store">
    <input name="nim" placeholder="NIM"><br>
    <input name="nama" placeholder="Nama"><br>
    <input name="alamat" placeholder="Alamat"><br>
    <input name="no_hp" placeholder="No HP"><br>
    <button type="submit">Simpan</button>
</form>
